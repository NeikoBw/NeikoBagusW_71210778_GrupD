class NodePelanggan():
    def __init__(self, namaPelanggan):
        self._namaPelanggan = namaPelanggan
    def getNamaPelanggan(self):
        return self._namaPelanggan
    def setnamaPelanggan(self, namaPelangganBaru):
        self._namaPelanggan = namaPelangganBaru

class kasir :
    Kapasitas = 5
    def __init__(self) :
        self._data = []
    def __len__(self) :
        return len(self._data)
    def is_empty(self):
        return self.__len__() == 0
    
    def deque(self):
        data = self._data[0]
        self._data.remove(data)
        print(f'Pelanggan{NodePelanggan.getNamaPelanggan(data)} Selesai Membayar')
        print()
        return data
    
    def enque(self, namaPelanggan):
        baru = NodePelanggan(namaPelanggan)
        if self.__len__() >= self.Kapasitas:
           print("SABAR NDAN KASIRNYA CUMA 3")
        self._data.append(baru)

    def printAll(self):
        print("===== KASIR =====")
        for i in range(0,self.Kapasitas):
            if i >= self.__len__():
                print(f"{i+1}. KOSONG")
            else:
                print(f"{i+1}",NodePelanggan.getNamaPelanggan(self._data[i]))
        print()

#TEST CASE
Kasir = kasir()
Kasir.enque("Sindu")
Kasir.enque("Silvi")
Kasir.enque("Hanif")
Kasir.enque("Shallom")
Kasir.enque("Dedi")
Kasir.printAll()
Kasir.enque("Tiur")
Kasir.printAll()
Kasir.deque()
Kasir.printAll()
Kasir.enque("Richard")
Kasir.printAll()
Kasir.deque()
Kasir.printAll()

    