import pickle
import os

FILE_NAME = "root.pk"
class Node:
    """
    Implementasi binary tree sederhana
    """
    def __init__(self, data):
        self.left = None
        self.right = None
        self.data = data
    

def get_node_awal(
        question="Apakah Ia bernafas?",
        noGuess="Komputer",
        yesGuess="Kucing") -> Node:
    """
    Fungsi ini akan mengembalikan node awal saat permainan dimulai.
    :param pertanyaan: pertanyaan awal yang akan muncul saat permainan dimulai. Defaultnya adalah "Apakah Ia bernafas?"
    :param noGuess: tebakan jika pilihan adalah Tidak. Defaultnya adalah "Komputer".
    :param yesGuess: tebakan jika pilihan adalah Ya. Defaultnya adalah "Anjing".
    :return value: Node awal pada left dan right children yang sesuai.
    """
    root = Node(question)
    root.left = Node(noGuess)
    root.right = Node(yesGuess)
    return root

def helper_get_node_jawaban() -> Node:
    """
    fungsi bantuan untuk mendapatkan jawaban dari User.
    :return: Node dengan jawaban didalamnya.
    """
    print("Saya tidak bisa menjawabnya! Tolong beritahu Saya?")
    while True:  # Looping untuk memastikan jawaban memiliki sedikitnya 1 karakter
        answer = input(">>").lower()
        if len(answer) < 1:
            print("Masukan jawaban yang benar sedikit berisi 1 karakter!")
            continue
        return Node(answer)  # kembalikan answer node.

def helper_jawaban_ya() -> bool:
    """
    Fungsi helper untuk mendapatkan jawaban Ya atau Tidak
    :return: True jika jawaban Ya, else False.
    """
    while True:
        answer = input(">>").lower()  # inputan dibuat menjadi lower-case
        if len(answer) < 1 or answer[0] not in ('y', 't'):  # tanyakan ulang jika user tidak menjawab dengan benar
            print("Maaf saya tidak paham jawaban Anda. Silahkan menuliskan Ya atau Tidak.")
            continue  # ulangi loop selama inputan tidak sesuai.

        if answer[0] == 'y':
            return True
        else:
            return False


def helper_get_node_pertanyaan(wrongNode) -> Node:
    """
    fungsi bantuan yang menampilkan pertanyaan yang akan diberikan aplikasi berdasarkan jawaban dari user.
    :param wrongNode: Node yang akan ditampilkan untuk membedakan jawaban yang akan ditebak.
    :return: Node dengan pertanyaan didalamnya.
    """
    print(f"Tolong berikan pertanyaan berbentuk 'Ya' atau 'Tidak', yang berbeda dari : {wrongNode.data}.")
    while True:  # Loop untuk memastikan user memberikan pertanyaan yang benar.
        question = input(">>").capitalize()
        if len(question) < 2 or question[-1] != "?":
            print("Tolong pastikan Anda memasukan pertanyaan yang valid. Sebagai contoh, 'Apakah ia mengeong ?' (tanpa quotes)")
            continue
        return Node(question)


def masukan_pertanyaan_dan_jawaban(wrongNode) -> Node:
    """
    Fungsi yang dipanggil saat node tidak memiliki child node yang tepat
    :param wrongNode: node salah yang akan dimodifikasi
    :return: Node yang dimodifikasi dengan pertanyaan dan jawaban baru.
    """
    answerNode = helper_get_node_jawaban()
    questionNode = helper_get_node_pertanyaan(wrongNode)

    print("Bagus! Apakah jawaban pertanyaan Anda? (Tulis Ya atau Tidak)")
    if helper_jawaban_ya():
        questionNode.right = answerNode
        questionNode.left = wrongNode
    else:
        questionNode.left = answerNode
        questionNode.right = wrongNode

    return questionNode


def ubah_node(childNode, parentNode, direction):
    """
    Mengubah Node
    :param childNode: child node yang akan diubah menjadi pertanyaan.
    :param parentNode: Parent node yang refrensinya akan diupdate.
    :param direction: Direction dari parent node yang refrensinya akan berubah.
    :return: None
    """
    if direction == 'left':
        parentNode.left = masukan_pertanyaan_dan_jawaban(childNode)
    else:
        parentNode.right = masukan_pertanyaan_dan_jawaban(childNode)


def gameLoop(root):
    """
    Main game loop untuk memainkan game.
    :param root: Parent root untuk mulai menanyakan pertanyaan.
    :return: Root dengan jawaban baru (if diinputkan).
    """
    copy = root  # copy initial root node.
    parent = None  # dapatkan parent node saat traversing.
    direction = None  # Track arah child node dari parent node.

    while root:  # Traverse dimulai dari root.
        if root.left == root.right:  # Kita sampai pada leaf node.
            print(f"Apakah itu {root.data}?")
            if helper_jawaban_ya():
                print("Saya menang!")
            else:
                ubah_node(root, parent, direction)  # Ubah leaf node dan gunakan sebagai node pertanyaan.
            root = None  # Set root ke None jika game sudah selesai
        else:  # kita berada pada node pertanyaan question.
            print(root.data)
            parent = root
            if helper_jawaban_ya():
                direction = "right"
                root = root.right
            else:  # user menjawab tidak.
                direction = 'left'
                root = root.left

    return copy  # Kembalikan parent node.

def play():
    root = get_node_awal()
    while True:
        root = gameLoop(root)
        print("\nHore! Kita telah menyelesaikan permainan. Apakah Anda ingin bermain lagi?")
        if helper_jawaban_ya():
            continue
        else:
            print("Sampai Jumpa!.")
            break

if __name__ == '__main__':
    play()